### FOR : [TNT_SOLO](https://t.me/S_OL_O7) ###

![TNT_SOLO](https://telegra.ph/file/e11b4793f160883d7af72-da4fbb38f915bfc93c.jpg)
